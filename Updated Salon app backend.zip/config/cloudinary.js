// config/cloudinary.js
const cloudinary = require('cloudinary').v2;

// Hard-code the configuration to eliminate any environment variable issues
cloudinary.config({
  cloud_name: 'dbexxjvcm',
  api_key: '297973581985788',
  api_secret: 'p1E0owZ2VzvQzGTAfbM5uxv3mlA',
  secure: true,
});

// Verify configuration is applied
const config = cloudinary.config();
console.log('🔧 Cloudinary Configuration Applied:');
console.log('   Cloud Name:', config.cloud_name);
console.log('   API Key:', config.api_key);
console.log('   API Secret:', config.api_secret ? '***SET***' : '❌ NOT SET');
console.log('   Secure:', config.secure);

// Test the configuration immediately
(async () => {
  try {
    const pingResult = await cloudinary.api.ping();
    console.log('✅ Cloudinary config test successful:', pingResult.status);
  } catch (error) {
    console.error('❌ Cloudinary config test failed:', error.message);
  }
})();

module.exports = cloudinary;
